package com.luv2code.springdemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("AppContext.xml");
		CricketCoach c= context.getBean("coach",CricketCoach.class);
		CricketCoach c2= context.getBean("coach",CricketCoach.class);
		System.out.println(c.getActivity()+"\n"+c.getFortune()+"\n"+c.getEmail()+"\n"+c.getTeam());
		System.out.println(c2.getActivity()+"\n"+c2.getFortune()+"\n"+c2.getEmail()+"\n"+c2.getTeam());
		Coach c1=context.getBean("coach1",Coach.class);
		System.out.println(c1.getActivity()+"\n"+c1.getFortune());
		System.out.println(c+""+c2+(c==c2));
		context.close();
	}

}
