package com.luv2code.springdemo;

public class BaseballCoach implements Coach{
	private FortuneService service;
	public BaseballCoach(FortuneService fs) {
		service=fs;
	}
	@Override
	public String getActivity() {
		// TODO Auto-generated method stub
		return "Do Baseball training";
	}
	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return service.getFortune();
	}

}
