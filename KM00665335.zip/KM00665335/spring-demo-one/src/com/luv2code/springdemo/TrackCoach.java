package com.luv2code.springdemo;

public class TrackCoach implements Coach{
private FortuneService service;
TrackCoach(FortuneService fs){
	service=fs;
}
	@Override
	public String getActivity() {
		// TODO Auto-generated method stub
		return "Do Track training";
	}

	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return service.getFortune();
	}
	
	public void start() {
		System.out.println("TrackCoach starting UP");
	}
	
	public void stop() {
		System.out.println("TrackCoach shutting DOWN");
	}
}
