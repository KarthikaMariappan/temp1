package com.sample.dao;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.sample.dao.DepartmentDAO;
import com.sample.entity.Department;

public class DeparmentDAOTest {

	DepartmentDAO dao = null;

	@Before
	public void setUp() {
		dao = new DepartmentDAO();
	}

	@Test
	public void getAllDepartmentTest() {
		List<Department> departments = dao.getAllDepartments();
		departments.forEach(System.out::println);
	}
	
	@Test
	public void getAllDepartmentTest1() {
		dao.getAllDepartmentsv1();
	}
	@Test
	public void getDepartmentTest() {
		Department department = dao.getDepartment(1);
		System.out.println();System.out.println();
		System.out.println(department);
		Assert.assertNotNull(department);
	}
	
	
	@Test
	public void createDepartmentTest(){
		Department newDepartment = new Department();
		newDepartment.setDepartmentName("TEST");
		dao.createDepartment(newDepartment);
		Assert.assertTrue(true);
	}
	
	
	@Test
	public void updateDepartmentTest(){
		Department oldDepartment = new Department();
		oldDepartment.setDepartmentId(102);
		oldDepartment.setDepartmentName("TEST 102");
		oldDepartment.setCreatedBy("ADMIN");
		dao.updateDepartment(oldDepartment);
		Assert.assertTrue(true);
	}
	
	@Test
	public void deleteDepartmentTest(){
		dao.deleteDepartment(102);
		Assert.assertTrue(true);
	}
	
	@Test
	public void getDepartmentSessionCacheTest() {
		dao.getDepartmentSessionCache(1);
	}
}
