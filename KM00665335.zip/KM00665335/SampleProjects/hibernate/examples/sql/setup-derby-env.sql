PATH C:\Program Files\Java\jdk1.8.0_25\db\bin
DERBY_HOME C:\Program Files\Java\jdk1.8.0_25\db
 
Go to Your Prefered Location using command line:
 
To start the Derby Database Server:
 
cd D:\balachandar\Database\school (Your location)
java -jar "%DERBY_HOME%\lib\derbyrun.jar" server start
 
 
To open client console:
cd D:\balachandar\Database\school (Your location)
>ij
(First time)
>CONNECT 'jdbc:derby://localhost:1527/training;create=true;user=root;password=root'; 
(Subsequent Time)
>CONNECT 'jdbc:derby://localhost:1527/training;user=root;password=root';





    