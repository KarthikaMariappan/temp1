

Sample Requests:

http://localhost:8889/api/departments - Method GET
http://localhost:8889/api/departments/1 - Method GET

New Department Creation:

Accept application/json
Content-Type application/json

http://localhost:8889/api/departments - Method POST
{
    "name": "TEST"
}


Department Updation:

http://localhost:8889/api/departments/7 - Method PUT
{"number":7,"name":"TEST"}

Department DELETION:
http://localhost:8889/api/departments/7

http://localhost:8889/api/employees - Method GET
http://localhost:8889/api/employees/1 - Method GET

New Employee Creation:

Accept application/json
Content-Type application/json

http://localhost:8889/api/employees - Method POST

{
    "firstName": "FIRST",
    "lastName": "LAST",
    "gender": "M",
    "age": 25,
    "email": "TEST@gmail.com",
    "phoneNumber": "1234567891",
    "hireDate": 1138213800000,
    "salary": 8000,
    "departmentId": {
        "number": 2,
        "name": "MATHS"
    }
}



Employee Updation: - Method PUT

{
    "employeeId": 7,
    "firstName": "FIRST-Update",
    "lastName": "LAST",
    "gender": "M",
    "age": 25,
    "email": "TEST@gmail.com",
    "phoneNumber": "1234567891",
    "hireDate": 1138213800000,
    "salary": 8000,
    "departmentId": {
        "number": 2,
        "name": "MATHS"
    }
}


Employee DELETION"
http://localhost:8889/api/employees/1 - Method GET






--------------------------- DERBY REFERENCE --------------------------------
PATH C:\Program Files\Java\jdk1.8.0_25\db\bin
DERBY_HOME C:\Program Files\Java\jdk1.8.0_25\db
 
Go to Your Prefered Location using command line:
 
To start the Derby Database Server:
 
cd D:\balachandar\Database\school (Your location)
java -jar "%DERBY_HOME%\lib\derbyrun.jar" server start
 
 
To open client console:
cd D:\balachandar\Database\school (Your location)
>ij
>CONNECT 'jdbc:derby://localhost:1527/testdb;create=true;user=root;password=root'; (First time)
>CONNECT 'jdbc:derby://localhost:1527/testdb;user=root;password=root';(Subsequent Time)
'jdbc:derby://localhost:1527/training;user=root;password=root';

>CONNECT 'jdbc:derby://localhost:1527/testdb;user=root;password=root';(Subsequent Time)


-------------------------------------------------------------------------------------

DERBY  SQL :


CREATE TABLE  DEPARTMENTS (
  DEPARTMENT_ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
  DEPARTMENT_NAME VARCHAR(30) NOT NULL,
  CREATED_BY VARCHAR(20)
);
 
 
CREATE TABLE  EMPLOYEES (
  EMPLOYEE_ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
  FIRST_NAME VARCHAR(20) NOT NULL,
  LAST_NAME VARCHAR(20) NOT NULL,
  EMAIL VARCHAR(20),
  GENDER CHAR  NOT NULL,
  AGE INTEGER NOT NULL,
  PHONE_NUMBER VARCHAR(20) NOT NULL,
  DEPARTMENT_ID_FK INTEGER NOT NULL,
  HIRE_DATE DATE NOT NULL,
  SALARY INTEGER NOT NULL,
  MANAGER_ID INTEGER,  
  CREATED_BY VARCHAR(20)
);
 
ALTER TABLE DEPARTMENTS ADD PRIMARY KEY(DEPARTMENT_ID);
ALTER TABLE EMPLOYEES ADD PRIMARY KEY(EMPLOYEE_ID);
 
ALTER TABLE EMPLOYEES ADD FOREIGN KEY (DEPARTMENT_ID_FK) REFERENCES DEPARTMENTS(DEPARTMENT_ID);
ALTER TABLE EMPLOYEES ADD FOREIGN KEY (MANAGER_ID) REFERENCES EMPLOYEES(EMPLOYEE_ID);
 
SELECT DEPARTMENT_ID, DEPARTMENT_NAME FROM DEPARTMENTS;
SELECT EMPLOYEE_ID, FIRST_NAME, LAST_NAME, DEPARTMENT_ID_FK  FROM EMPLOYEES;
 
 
insert into DEPARTMENTS (DEPARTMENT_NAME) values ('Physics');
insert into DEPARTMENTS (DEPARTMENT_NAME) values ('CS');
INSERT INTO DEPARTMENTS (DEPARTMENT_NAME)VALUES('Chemistry');



INSERT INTO EMPLOYEES(FIRST_NAME,LAST_NAME,GENDER,AGE,EMAIL,PHONE_NUMBER,HIRE_DATE,SALARY,DEPARTMENT_ID_FK,MANAGER_ID)
	    VALUES('ARIVU','KUMAR','M',35,'sample0@gmail.com','1234567890',DATE('2006-01-26'),10000,1,1);
INSERT INTO EMPLOYEES(FIRST_NAME,LAST_NAME,GENDER,AGE,EMAIL,PHONE_NUMBER,HIRE_DATE,SALARY,DEPARTMENT_ID_FK,MANAGER_ID)
	    VALUES('BABU','RAMU','M',25,'sample1@gmail.com','1234567891',DATE('2006-01-26'),8000,2,1);
INSERT INTO EMPLOYEES(FIRST_NAME,LAST_NAME,GENDER,AGE,EMAIL,PHONE_NUMBER,HIRE_DATE,SALARY,DEPARTMENT_ID_FK,MANAGER_ID)
	    VALUES('RANI','ASHOK','F',23,'sample2@gmail.com','1234567892',DATE('2006-01-26'),8000,3,1);
INSERT INTO EMPLOYEES(FIRST_NAME,LAST_NAME,GENDER,AGE,EMAIL,PHONE_NUMBER,HIRE_DATE,SALARY,DEPARTMENT_ID_FK,MANAGER_ID)
	    VALUES('DEVI','SARAVANAN','F',23,'sample3@gmail.com','1234567893',DATE('2006-01-26'),8000,3,1);
INSERT INTO EMPLOYEES(FIRST_NAME,LAST_NAME,GENDER,AGE,EMAIL,PHONE_NUMBER,HIRE_DATE,SALARY,DEPARTMENT_ID_FK,MANAGER_ID)
	    VALUES('DURAI','NAVEEN','M',23,'sample4@gmail.com','1234567894',DATE('2006-01-26'),8000,3,1);
INSERT INTO EMPLOYEES(FIRST_NAME,LAST_NAME,GENDER,AGE,EMAIL,PHONE_NUMBER,HIRE_DATE,SALARY,DEPARTMENT_ID_FK,MANAGER_ID)
	    VALUES('KESAVAN','MUTHU','M',23,'sample5@gmail.com','1234567895',DATE('2006-01-26'),8000,3,1);
	    
	    
-------------------------------------------------------------------------------------

