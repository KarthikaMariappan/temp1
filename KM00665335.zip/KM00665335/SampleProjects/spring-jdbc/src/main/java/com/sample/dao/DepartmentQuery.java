package com.sample.dao;

public class DepartmentQuery {

	private String getAllDepartmentQuery;
	private String getDepartmentByIdQuery;
	private String getDepartmentByNameQuery;
	private String insertDepartmentQuery;
	private String updateDepartmentQuery;
	private String deleteDepartmentQuery;
	public String getGetAllDepartmentQuery() {
		return getAllDepartmentQuery;
	}
	public void setGetAllDepartmentQuery(String getAllDepartmentQuery) {
		this.getAllDepartmentQuery = getAllDepartmentQuery;
	}
	public String getGetDepartmentByIdQuery() {
		return getDepartmentByIdQuery;
	}
	public void setGetDepartmentByIdQuery(String getDepartmentByIdQuery) {
		this.getDepartmentByIdQuery = getDepartmentByIdQuery;
	}
	public String getGetDepartmentByNameQuery() {
		return getDepartmentByNameQuery;
	}
	public void setGetDepartmentByNameQuery(String getDepartmentByNameQuery) {
		this.getDepartmentByNameQuery = getDepartmentByNameQuery;
	}
	public String getInsertDepartmentQuery() {
		return insertDepartmentQuery;
	}
	public void setInsertDepartmentQuery(String insertDepartmentQuery) {
		this.insertDepartmentQuery = insertDepartmentQuery;
	}
	public String getUpdateDepartmentQuery() {
		return updateDepartmentQuery;
	}
	public void setUpdateDepartmentQuery(String updateDepartmentQuery) {
		this.updateDepartmentQuery = updateDepartmentQuery;
	}
	public String getDeleteDepartmentQuery() {
		return deleteDepartmentQuery;
	}
	public void setDeleteDepartmentQuery(String deleteDepartmentQuery) {
		this.deleteDepartmentQuery = deleteDepartmentQuery;
	}
	
	
	
	
	

}
