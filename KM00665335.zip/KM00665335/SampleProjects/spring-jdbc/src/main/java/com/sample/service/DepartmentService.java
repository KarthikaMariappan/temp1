package com.sample.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.Department;
import com.sample.dao.DepartmentDAOInterface;

@Service
public class DepartmentService{
	private DepartmentDAOInterface departmentDAO; 
	
	public List<Department> listAllDepartments(){
		return departmentDAO.listAllDepartments();
	}
	
	public Department selectDepartmentById(int departmentId){
		Department department = departmentDAO.selectDepartmentById(departmentId);
		return department;
	}
	
	public Department selectDepartmentByName(String departmentName){
    	Department department = departmentDAO.selectDepartmentByName(departmentName);
		return department;
	}
	
	@Transactional
	public void insertDepartment(Department department){
		departmentDAO.insertDepartment(department);
	}
	
	@Transactional
	public void updateDepartment(Department department){
		departmentDAO.updateDepartment(department);
	}
	
	@Transactional
	public void deleteDepartment(int departmentId){
		departmentDAO.deleteDepartment(departmentId);
	}

	public void setDepartmentDAO(DepartmentDAOInterface departmentDAO) {
		this.departmentDAO = departmentDAO;
	}
	
	
}
