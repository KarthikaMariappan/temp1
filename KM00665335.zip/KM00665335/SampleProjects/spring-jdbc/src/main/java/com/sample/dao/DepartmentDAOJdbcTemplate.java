package com.sample.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;



import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.sample.Department;

public class DepartmentDAOJdbcTemplate extends DepartmentQuery implements DepartmentDAOInterface{
	
	private JdbcTemplate jdbcTemplate;

	private RowMapper<Department> departmentMapper = new RowMapper<Department>() {
        public Department mapRow(ResultSet rs, int rowNum) throws SQLException {
        	Department department = new Department();
        	department.setDepartmentId((rs.getInt("DEPARTMENT_ID")));
        	department.setDepartmentName(rs.getString("DEPARTMENT_NAME"));
            return department;
        }
    };
	

	public List<Department> listAllDepartments(){
		return jdbcTemplate.query("SELECT * FROM DEPARTMENTS", departmentMapper);
	}
	

	public Department selectDepartmentById(int departmentId){
		return jdbcTemplate.queryForObject(getGetDepartmentByIdQuery(), departmentMapper,departmentId);
	}
	

	public Department selectDepartmentByName(String departmentName){
		return jdbcTemplate.queryForObject(getGetDepartmentByNameQuery(), departmentMapper,departmentName);
	}
	

	public void insertDepartment(final Department department){
		//INSERT INTO DEPARTMENTS (DEPARTMENT_NAME)VALUES(?)
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
	        public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
	            PreparedStatement ps =
	                connection.prepareStatement(getInsertDepartmentQuery(), new String[] {"id"});
	            ps.setString(1, department.getDepartmentName());
	            return ps;
	        }
	    },
	    keyHolder);

		System.out.println("Generated Primary Key is :    -> " + keyHolder.getKey());

	}

	public void updateDepartment(Department department){
		jdbcTemplate.update(getUpdateDepartmentQuery(),department.getDepartmentName(),department.getDepartmentId());
		//UPDATE DEPARTMENTS SET DEPARTMENT_NAME = ? WHERE DEPARTMENT_ID = ?
	}
	

	public void deleteDepartment(int departmentId){
		jdbcTemplate.update(getDeleteDepartmentQuery(),departmentId);
	}


	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	
}
