package com.sample.dao.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sample.Department;
import com.sample.dao.DepartmentDAOInterface;

public class DepartmentDAOTest {

	private DepartmentDAOInterface departmentDAO = null;
	
	
	public static void main(String args[]) {
		DepartmentDAOTest test = new DepartmentDAOTest();
		//test.testInsertDepartment();
		//test.testGetAllDepartment();
		test.testGetByDepartmentId();
		//test.testUpdateByDepartmentId();
		//test.testDeleteByDepartmentId();
	}
	

	public void setup(){
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		departmentDAO = (DepartmentDAOInterface) context.getBean("departmentDaoJdbcTemplate");
	}
	

	public void testInsertDepartment(){
		setup();
		Department department = new Department();
		department.setDepartmentName("Sample" + Math.random());
		departmentDAO.insertDepartment(department);
		
		Department obj = departmentDAO.selectDepartmentByName(department.getDepartmentName());
		System.out.println("Department Id is : " + obj.getDepartmentId());
	}
	
	
	public void testGetAllDepartment(){
		setup();
		List<Department> departmentList = departmentDAO.listAllDepartments();
		for( Department obj : departmentList) {
			System.out.println("Department Name is : ->" + obj);
		}
		System.out.println("Department Size is :     -> " + departmentList.size());
	}
	
	public void testGetByDepartmentId(){
		setup();
		Department department = departmentDAO.selectDepartmentById(1);
		System.out.println("Department is : " + department);
	}

	public void testUpdateByDepartmentId(){
		setup();
		Department department = departmentDAO.selectDepartmentById(6);
		String updatedDepartmentName = department.getDepartmentName() + "Updated";
		department.setDepartmentName(updatedDepartmentName);
		departmentDAO.updateDepartment(department);
		Department modifiedDepartment = departmentDAO.selectDepartmentById(6);
		System.out.println("Modified Deparment is : -> " + modifiedDepartment);
	}
	
	public void testDeleteByDepartmentId(){
		setup();
		Department beforeDelete = departmentDAO.selectDepartmentById(5);
		System.out.println("Before Delete Deparment is : -> " + beforeDelete);
    	departmentDAO.deleteDepartment(5);
		Department afterDelete = departmentDAO.selectDepartmentById(5);
	}
	
}


