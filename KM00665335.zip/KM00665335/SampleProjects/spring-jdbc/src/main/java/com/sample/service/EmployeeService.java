package com.sample.service;

import java.util.List;

import com.sample.Employee;
import com.sample.dao.EmployeeDAO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EmployeeService{
	
	private EmployeeDAO employeeDAO; 
	

	public List<Employee> listAllEmployees(){
		return employeeDAO.listAllEmployees();
	}
	
	public Employee selectEmployeeById(int employeeId){
		return employeeDAO.selectEmployeeById(employeeId);
	}
	
	public List<Employee> getEmployeesByDepartment(int departmentId){
		return employeeDAO.getEmployeesByDepartment(departmentId);
	}
	
	@Transactional
	public void insertEmployee(Employee employee){
		employeeDAO.insertEmployee(employee);
	}
	
	@Transactional
	public void updateEmployee(Employee employee){
		employeeDAO.updateEmployee(employee);
	}
	
	@Transactional
	public void deleteEmployee(int employeeId){
		employeeDAO.deleteEmployee(employeeId);
	}

	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}
	
	
	
}
