package com.sample.dao;

import java.util.List;

import com.sample.Department;

public interface DepartmentDAOInterface {

	public List<Department> listAllDepartments();
	public Department selectDepartmentById(int departmentId);
	public Department selectDepartmentByName(String departmentName);
	public void insertDepartment(Department department);
	public void updateDepartment(Department department);
	public void deleteDepartment(int departmentId);
}
