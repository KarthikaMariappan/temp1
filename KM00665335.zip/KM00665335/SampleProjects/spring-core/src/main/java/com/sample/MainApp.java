package com.sample;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.core.io.ClassPathResource;

public class MainApp {

	public static void main(String[] args) {

		  DefaultListableBeanFactory beanFactory = new DefaultListableBeanFactory();
	      XmlBeanDefinitionReader beanDefinitionReader=new XmlBeanDefinitionReader(beanFactory);
	      beanDefinitionReader.loadBeanDefinitions(new ClassPathResource("Beans.xml"));
	      HelloWorld obj = (HelloWorld) beanFactory.getBean("hello");
	      obj.getMessage();
	   }
}


// http://www.programcreek.com/java-api-examples/index.php?api=org.springframework.beans.factory.xml.XmlBeanDefinitionReader