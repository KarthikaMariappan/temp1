package com.service;

import org.springframework.stereotype.Component;

@Component
public class EmailService implements MessageService {
	 
    public boolean sendMessage(String msg, String receipient) {
        System.out.println("Email Sent to " + receipient + " with Message="+msg);
        return true;
    }
 
}
