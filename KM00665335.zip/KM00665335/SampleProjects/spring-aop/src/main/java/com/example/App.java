package com.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.aspect.AspectConfig;
import com.example.dao.CustomerDaoInterface;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	aspectStyleV1();
    }
    
    private static void aspectStyleV1() {
    	//ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
    	ApplicationContext context = new AnnotationConfigApplicationContext(AspectConfig.class);
    	CustomerDaoInterface obj = (CustomerDaoInterface) context.getBean("customerDao");
        
    	//obj.addCustomer();
    	
    	//String result = obj.addCustomerReturnValue();
    	//System.out.println("Result Value is : " + result);
    	
    	/*try {
			obj.addCustomerThrowException();
		} catch (Exception e) {
			e.printStackTrace();
		}*/
    	
    	obj.addCustomerAround("abc");
    }
    
    
    private static void aspectStyleV2() {
    	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContextDescriptor.xml");
    	//ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
    	CustomerDaoInterface obj = (CustomerDaoInterface) context.getBean("customerDao");
        
    	//obj.addCustomer();
    	
    	//String result = obj.addCustomerReturnValue();
    	//System.out.println("Result Value is : " + result);
    	
    	/*try {
			obj.addCustomerThrowException();
		} catch (Exception e) {
			e.printStackTrace();
		}*/
    	
    	obj.addCustomerAround("abc");
    }
    
    private static void aspectStyleV3() {
    	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContextWithoutAspectj.xml");
    	CustomerDaoInterface obj = (CustomerDaoInterface) context.getBean("customerDaoProxy");
        
    	//obj.addCustomer();
    	
    	//String result = obj.addCustomerReturnValue();
    	//System.out.println("Result Value is : " + result);
    	
    	/*try {
			obj.addCustomerThrowException();
		} catch (Exception e) {
			e.printStackTrace();
		}*/
    	
    	obj.addCustomerAround("abc");
    }
    
}
