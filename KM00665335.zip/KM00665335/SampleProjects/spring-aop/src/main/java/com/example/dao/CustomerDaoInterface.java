package com.example.dao;

public interface CustomerDaoInterface {
	
	void addCustomer();
	 
	String addCustomerReturnValue();
 
	void addCustomerThrowException() throws Exception;
 
	void addCustomerAround(String name);
}
