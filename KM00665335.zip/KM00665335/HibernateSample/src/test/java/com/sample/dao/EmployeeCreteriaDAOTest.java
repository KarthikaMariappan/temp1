package com.sample.dao;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.sample.entity.Employee;

public class EmployeeCreteriaDAOTest {

	
	EmployeeCriteriaDAO dao = null;
	
	@Before
	public void init(){
		dao = new EmployeeCriteriaDAO();
	}
	
	
	@Test
	public void testGetAllEmployees(){
		List<Employee> employees = dao.getAllEmployees();
		System.out.println("\n \n \n Employee Records are : \n \n \n");
		employees.forEach(System.out::println);
	}
	
	
	@Test
	public void testGetEmployeeByIdTest(){
		Employee employee = dao.getEmployeeById(1);
		System.out.println(employee);
	}
	
	
	
	@Test
	public void testGetEmployeeByGender(){
		List<Employee> employees = dao.getEmployeeByGender("F");
		System.out.println("\n \n \n Employee Records are : \n \n \n");
		employees.forEach(System.out::println);
	}
	
	@Test
	public void testGetEmployeeByAge(){
		List<Employee> employees = dao.getEmployeeByAge(23);
		System.out.println("\n \n \n Employee Records are : \n \n \n");
		employees.forEach(System.out::println);
	}
	
	@Test
	public void testGetTopSalaryEmployee(){
		List<Employee> employees = dao.getTopSalaryEmployee();
		System.out.println("\n \n \n Employee Records are : \n \n \n");
		employees.forEach(System.out::println);
	}
	
	
	@Test
	public void testGetEmployeeByDepartment(){
		List<Employee> employees = dao.getEmployeeByDepartment("PHY");
		System.out.println("\n \n \n Employee Records are : \n \n \n");
		employees.forEach(System.out::println);
	}
	
}
