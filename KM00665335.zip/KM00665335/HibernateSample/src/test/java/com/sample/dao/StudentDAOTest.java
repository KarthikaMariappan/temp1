package com.sample.dao;

import org.junit.Before;
import org.junit.Test;

import com.sample.entity.Student;
import com.sample.entity.StudentAddress;

public class StudentDAOTest {

	
	StudentDAO dao = null;

	@Before
	public void setUp() {
		dao = new StudentDAO();
	}
	
	@Test
	public void insertStudentDAOTest(){
		
		Student student = new Student("Nandakumar", "Babu", "java@gmail.com", "1289871234" );  
        StudentAddress studentAddress = new StudentAddress("AK-47, SEC-47", "Tambaram", "Chennai", "India");  
          
        student.setStudentAddress(studentAddress);  
        studentAddress.setStudent(student);  

        dao.insertStrudent(student);
	}
	
}
