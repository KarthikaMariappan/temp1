package com.sample.dao;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.sample.entity.Department;
import com.sample.entity.Employee;

public class EmployeeHQLDAOTest {

	
	EmployeeHQLDAO dao = null;
	
	@Before
	public void init(){
		dao = new EmployeeHQLDAO();
	}
	
	
	@Test
	public void testGetAllEmployees(){
		List<Employee> employees = dao.getAllEmployees();
		System.out.println("\n \n \n Employee Records are : \n \n \n");
		employees.forEach(System.out::println);
	}
	
	
	@Test
	public void testGetEmployeeById(){
		Employee employee = dao.getEmployeeById(101);
		System.out.println(employee);
	}
	
	
	
	@Test
	public void testGetEmployeeByGender(){
		List<Employee> employees = dao.getEmployeeByGender("F");
		System.out.println("\n \n \n Employee Recordsss are : \n \n \n");
		employees.forEach(System.out::println);
	}
	
	@Test
	public void testGetEmployeeByDepartment(){
		List<Employee> employees = dao.getEmployeeByDepartment("PHY");
		System.out.println("\n \n \n Employee Records are : \n \n \n");
		employees.forEach(System.out::println);
	}
	
	@Test
	public void testGetEmptyDepartment(){
		List<Department> departments = dao.getEmptyDepartment();
		System.out.println("\n \n \n Department who does not have employees : \n \n \n");
		departments.forEach(System.out::println);
	}
	
}
