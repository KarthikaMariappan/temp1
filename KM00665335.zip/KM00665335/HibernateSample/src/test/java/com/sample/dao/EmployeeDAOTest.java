package com.sample.dao;

import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.sample.entity.Department;
import com.sample.entity.Employee;

public class EmployeeDAOTest {

	EmployeeDAO dao = null;

	@Before
	public void setUp() {
		dao = new EmployeeDAO();
	}
	
	@Test
	public void getAllEmployeeTest() {
		List<Employee> employees = dao.getAllEmployees();
		employees.forEach(System.out::println);
	}
	
	
	@Test
	public void getEmployeeTest() {
		Employee employee = dao.getEmployee(1);
		System.out.println();System.out.println();
		System.out.println(employee);
		Assert.assertNotNull(employee);
	}
	
	
	
	@Test
	public void creatEmployeeTest(){
		Employee newEmployee = new Employee();
		
		newEmployee.setFirstName("TEST");
		newEmployee.setLastName("RAJU");
		newEmployee.setGender("M");
		newEmployee.setAge(30);
		newEmployee.setEmail("le6@gmail.com");
		newEmployee.setPhoneNumber("1234567896");
		newEmployee.setHireDate(new Date());
		newEmployee.setSalary(10000);
		
		Department department = new Department();
		department.setDepartmentId(1);
		newEmployee.setDepartmentId(department);
		
		dao.creatEmployee(newEmployee);
		Assert.assertTrue(true);
	}
	
}
