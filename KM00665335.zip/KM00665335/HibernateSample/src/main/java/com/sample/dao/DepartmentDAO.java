package com.sample.dao;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sample.entity.Department;
import com.sample.util.HibernateUtil;

public class DepartmentDAO {

	public List<Department> getAllDepartments(){
		Session session = HibernateUtil.getSession();
		Query query =  session.createQuery("from Department");
		List<Department> departments = query.list();///
		session.close();
		return departments;
	}
	
	public Department getDepartment(int departmentId){
		Session session = HibernateUtil.getSession();
		Department department = (Department) session.load(Department.class, departmentId);
		//Department department = (Department) session.get(Department.class, departmentId);
		System.out.println("*** I am going to get the ID ***");
		department.getDepartmentId();
		session.close();
		return department;
	}
	
	
	public void createDepartment(Department department){
		Session session = HibernateUtil.getSession();
		Transaction transaction = session.beginTransaction();
		session.save(department);
		transaction.commit();
		session.close();
	}

	
	public void updateDepartment(Department department){
		Session session = HibernateUtil.getSession();
		Transaction transaction = session.beginTransaction();
		session.update(department);
		transaction.commit();
		session.close();
	}
	
	
	public void deleteDepartment(int departmentId){
		Session session = HibernateUtil.getSession();
		Transaction transaction = session.beginTransaction();
		Department department = new Department();
		department.setDepartmentId(departmentId);
		session.delete(department);
		transaction.commit();
		session.close();
	}
	
	
	
	public void getDepartmentSessionCache(int departmentId){
		Session session = HibernateUtil.getSession();
		Transaction transaction = session.beginTransaction();
		System.out.println("*** I am going to get the record first time ***");
		Department departmentOne = (Department) session.get(Department.class, departmentId); // The object is retrieved from the database
		departmentOne.setDepartmentName("PHY");
		System.out.println();System.out.println();
		System.out.println("*** I am going to get the record second time ***");
		Department departmentTwo = (Department) session.get(Department.class, departmentId); // The object is retrieved from the cache 
		if ( departmentOne == departmentTwo ) {
		    System.out.println("departmentOne and departmentTwo are identicial and the same database identity.  " + departmentOne.getDepartmentName());
		}
		

		transaction.commit();
		session.close();
		System.out.println();System.out.println();
		System.out.println("*** Session was closed. Opening new session ***");
		session = HibernateUtil.getSession();
		Department departmentThree = (Department) session.get(Department.class, departmentId);//The object is retrieved from the database
		if ( departmentOne != departmentThree ) {
		    System.out.println("departmentOne and departmentThree are not identicial and the same database identity.  " + departmentOne.getDepartmentName() );
		}
		session.close();
	}

}
