package com.sample.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sample.entity.Student;
import com.sample.util.HibernateUtil;

public class StudentDAO {

	public void insertStrudent(Student student){
		Session session = HibernateUtil.getSession();
		Transaction transaction = session.beginTransaction();
		session.save(student);
		transaction.commit();
		session.close();
	}
	
}
