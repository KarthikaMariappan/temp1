package com.sample.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sample.entity.Employee;
import com.sample.util.HibernateUtil;

public class EmployeeDAO {
	
	public List<Employee> getAllEmployees(){
		Session session = HibernateUtil.getSession();
		Query query =  session.createQuery("from Employee");
		List<Employee> employees = query.list();///
		session.close();
		return employees;
	}
	
	public Employee getEmployee(int employeeId){
		Session session = HibernateUtil.getSession();
		Employee employee = (Employee) session.get(Employee.class, employeeId);
		session.close();
		return employee;
	}

	public void creatEmployee(Employee newEmployee){
		Session session = HibernateUtil.getSession();
		Transaction transaction = session.beginTransaction();
		session.save(newEmployee);
		transaction.commit();
		session.close();
	}
	
}
