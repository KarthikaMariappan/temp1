package com.sample.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

import com.sample.entity.Employee;
import com.sample.util.HibernateUtil;

public class EmployeeCriteriaDAO {

	public List<Employee> getAllEmployees(){
		Session session = HibernateUtil.getSession();
		Criteria criteria = session.createCriteria(Employee.class) ;
		List<Employee> employees = (List<Employee>)criteria.list();
		return employees;
	}
	
	public Employee getEmployeeById(int employeeId){
		Session session = HibernateUtil.getSession();
		Criteria criteria = session.createCriteria(Employee.class) ;
		criteria.add(Restrictions.eq("employeeId",employeeId));
		Employee employee = (Employee)criteria.uniqueResult();
		return employee;
	}
	
	public List<Employee> getEmployeeByGender(String gender){
		Session session = HibernateUtil.getSession();
		Criteria criteria = session.createCriteria(Employee.class) ;
		criteria.add(Restrictions.eq("gender",gender));
		List<Employee> employees = (List<Employee>)criteria.list();
		return employees;
	}
	
	public List<Employee> getEmployeeByAge(int age){
		Session session = HibernateUtil.getSession();
		Criteria criteria = session.createCriteria(Employee.class).add(Restrictions.or(
				Restrictions.eq("age",new Integer(age)),Restrictions.isNull("age"))) ;
		List<Employee> employees = (List<Employee>)criteria.list();
		return employees;
	}
	
	public List<Employee> getTopSalaryEmployee(){
		Session session = HibernateUtil.getSession();
		Criteria criteria = session.createCriteria(Employee.class)
			    .addOrder(Order.desc("salary")). setMaxResults(3)
			    .setFirstResult(2);
		List<Employee> employees = (List<Employee>)criteria.list();
		System.out.println("\n \n \n Employee Recordsss are : \n \n \n");
		return employees;
	}
	
	public List<Employee> getEmployeeByDepartment(String departmentName){
		Session session = HibernateUtil.getSession();
		Criteria criteria = session.createCriteria(Employee.class) ;
		criteria.createAlias("departmentId", "department");
		criteria.add(Restrictions.eq("department.departmentName",departmentName));
		List<Employee> employees = (List<Employee>)criteria.list();
		return employees;
	}
	
	public static List<Employee> projectionCriteriaSample(){
		Session session = HibernateUtil.getSession();
		Criteria criteria = session.createCriteria(Employee.class) ;
		ProjectionList proList = Projections.projectionList();
		proList.add(Projections.property("firstName"),"firstName");
		proList.add(Projections.property("salary"),"salary");
		criteria.setProjection(proList);
		criteria.setResultTransformer(Transformers.aliasToBean(Employee.class));
		List<Employee> employees = (List<Employee>)criteria.list();
		System.out.println("\n \n \n Employee Recordsss are : \n \n \n");
		employees.forEach(System.out::println);
		return employees;
	}
	
	public static void main(String args[]){
		projectionCriteriaSample();
	}
}
