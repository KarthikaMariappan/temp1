package com.sample.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.transform.Transformers;

import com.sample.entity.Employee;
import com.sample.entity.Department;
import com.sample.util.HibernateUtil;

public class EmployeeHQLDAO {

	private final static String GET_ALL_EMPLOYEE = "from Employee";
	private final static String GET_EMPLOYEE_BY_ID = "from Employee where employeeId = :ID";
	private final static String GET_EMPLOYEE_BY_GENDER = "from Employee where gender = ?";
	private final static String GET_EMPLOYEE_BY_DEPARTMENTT = "select e from Employee e inner join e.departmentId d where d.departmentName = :NAME";
	private final static String GET_EMPTY_DEPARTMENT = "select d from Department d left outer join d.employees where size(d.employees) = 0";

	public List<Employee> getAllEmployees(){
		Session session = HibernateUtil.getSession();
		Query query = session.createQuery(GET_ALL_EMPLOYEE);  
		List<Employee> employees = (List<Employee>)query.list();
		return employees;
	}
	
	public Employee getEmployeeById(int employeeId){
		Session session = HibernateUtil.getSession();
		Query query = session.createQuery(GET_EMPLOYEE_BY_ID).setInteger("ID", employeeId);
		Employee employee = (Employee)query.uniqueResult();
		return employee;
	}
	
	public List<Employee> getEmployeeByGender(String gender){
		Session session = HibernateUtil.getSession();
		Query query = session.createQuery(GET_EMPLOYEE_BY_GENDER).setString(0, gender);
		List<Employee> employees = (List<Employee>)query.list();
		return employees;
	}
	
	public List<Employee> getEmployeeByDepartment(String departmentName){
		Session session = HibernateUtil.getSession();
		Query query = session.createQuery(GET_EMPLOYEE_BY_DEPARTMENTT);
		query.setString("NAME", departmentName);
		List<Employee> employees = (List<Employee>)query.list();
		return employees;
	}
	
	public List<Department> getEmptyDepartment(){
		Session session = HibernateUtil.getSession();
		Query query = session.createQuery(GET_EMPTY_DEPARTMENT);
		List<Department> departments = (List<Department>)query.list();
		return departments;
	}
	
	public static void scalarQuerySample(){
		Session session = HibernateUtil.getSession();
		Query query = session.createQuery("select e.firstName as firstName, e.salary as salary from Employee e").setResultTransformer(Transformers.aliasToBean(Employee.class));
		List<Employee> employees = (List<Employee>)query.list();
		System.out.println("\n \n \n Employee Records are : \n \n \n");
		for(Employee obj:employees){
			System.out.println(obj);
		}
	}
	
	public static void nativeSQLSample(){
		Session session = HibernateUtil.getSession();
		Query query = session.createSQLQuery("select {e.*} from EMPLOYEES {e} where FIRST_NAME like 'D%'").addEntity("e", Employee.class);
		List<Employee> employees = (List<Employee>)query.list();
		System.out.println("\n \n \n Employee Records are : \n \n \n");
		for(Employee obj:employees){
			System.out.println(obj);
		}

	}
	

	public static void main(String args[]){
		//nativeSQLSample();
		//scalarQuerySample();
	}
}
