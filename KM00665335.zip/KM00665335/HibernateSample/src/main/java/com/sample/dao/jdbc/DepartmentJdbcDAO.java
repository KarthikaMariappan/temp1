package com.sample.dao.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.sample.entity.Department;

public class DepartmentJdbcDAO {
	
	static String CONNECTION_URL = "jdbc:derby://localhost:1527/training";
	static String DRIVER_NAME ="org.apache.derby.jdbc.ClientDriver";
	static String userName = "root";
	static String password = "root";

	public static void main(String[] args) {
		DepartmentJdbcDAO dao = new DepartmentJdbcDAO();
		listDepartments();
		//Department obj = createNewDepartment();dao.addDepartment(obj);
		//Department obj = createUpdatedDepartment(106);dao.updateDepartment(obj);
		//dao.deleteDepartment(105);
	}
	
	
	
	
	public List<Department> getAllDepartments(){
		
		List<Department> departmentList = new ArrayList<Department>();
		try(Connection con = DriverManager.getConnection(CONNECTION_URL, userName, password);Statement st = con.createStatement();ResultSet rs = st.executeQuery("SELECT * FROM DEPARTMENTS") ) {
			Class.forName(DRIVER_NAME);
			Department obj = null;
			while(rs.next()){
				obj = new Department();
				obj.setDepartmentId(rs.getInt("DEPARTMENT_ID"));
				obj.setDepartmentName(rs.getString("DEPARTMENT_NAME"));
				obj.setCreatedBy(rs.getString("CREATED_BY"));
				departmentList.add(obj);
			}
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e.toString());
		}		
		return departmentList;
	}
	
	
	public void addDepartment(Department obj){
		
		int  count = 0;
		String query = "INSERT INTO DEPARTMENTS(DEPARTMENT_NAME,CREATED_BY)VALUES(?,?)";
		try(Connection con= DriverManager.getConnection(CONNECTION_URL, userName, password);PreparedStatement st=con.prepareStatement(query);) {
			Class.forName(DRIVER_NAME);
			st.setString(1, obj.getDepartmentName());
			st.setString(2, obj.getCreatedBy());
			count = st.executeUpdate();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e.toString());
		}		
		System.out.println("New Record inserted Successfully.");
	}
	
	
	public void updateDepartment(Department obj){

		int  count = 0;
		String query = "UPDATE DEPARTMENTS SET DEPARTMENT_NAME = ? WHERE DEPARTMENT_ID = ? ";
		
		try (Connection con= DriverManager.getConnection(CONNECTION_URL, userName, password);PreparedStatement st = con.prepareStatement(query);){
			Class.forName(DRIVER_NAME);
			st.setString(1, obj.getDepartmentName());
			st.setInt(2, obj.getDepartmentId());
			count = st.executeUpdate();
			
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e.toString());
		}
		
		System.out.println("Record updated Successfully.");
		
	}
	
	
	public void deleteDepartment(int departmentId){
		
		PreparedStatement st = null;
		int  count = 0;
		Connection con = null;
		String query = "DELETE FROM DEPARTMENTS WHERE DEPARTMENT_ID = ? ";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(CONNECTION_URL, userName, password);
			st = con.prepareStatement(query);
			st.setInt(1, departmentId);
			count = st.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}finally{
			try {
				if(st!=null) {
					st.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		System.out.println("Deleted Successfully.");
		
	}
	
	
	private static Department createNewDepartment(){
		Department obj = new Department();
		obj.setDepartmentName("BBA");
		obj.setCreatedBy("ADMIN");
		return obj;
	}
	
	private static Department createUpdatedDepartment(int departmentId){
		Department obj = new Department();
		obj.setDepartmentId(departmentId);
		obj.setDepartmentName("BA");
		obj.setCreatedBy("ADMIN");
		return obj;
	}
	
	private static void listDepartments(){
		DepartmentJdbcDAO dao = new DepartmentJdbcDAO();
		List<Department> depList = dao.getAllDepartments();
		for(Department obj:depList){
			System.out.println(obj);
		}
	}

}
