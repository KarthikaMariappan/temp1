package com.sample.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="DEPARTMENTS")
public class Department {

	@Id
	@Column(name="DEPARTMENT_ID")
	@GeneratedValue
	private int departmentId;
	
	@Column(name="DEPARTMENT_NAME")
	private String departmentName;
	
	@Column(name="CREATED_BY")
	private String createdBy;
	
	@OneToMany(mappedBy = "departmentId", fetch = FetchType.LAZY)
	//@OneToMany(mappedBy = "departmentId", fetch = FetchType.EAGER)
	//@BatchSize(size = 2) // Working
	//@Fetch(FetchMode.SUBSELECT) // Working
	private List<Employee> employees = new ArrayList<Employee>();

	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	@Override
	public String toString() {
		return "Department [departmentId=" + departmentId + ", departmentName=" + departmentName + ", createdBy="
				+ createdBy + "]";
	}
	
}
	
	

