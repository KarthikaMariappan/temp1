package com.sample.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sample.entity.Stock;
import com.sample.util.HibernateUtil;

public class StockDAO {

	public void insertStock(Stock stock){
		Session session = HibernateUtil.getSession();
		Transaction transaction = session.beginTransaction();
		session.save(stock);
		transaction.commit();
		session.close();
	}
}
