package com.luv2code.spring;

import org.springframework.beans.factory.annotation.Value;

public class SwimCoach implements Coach {
	@Value("${email}")
	private String email;
	
	@Value("${team}")
	private String team;
	
	public String getEmail() {
		return email;
	}
	public String getTeam() {
		return team;
	}
	
	private FortuneService fortuneService;
	SwimCoach(FortuneService sfs){
		this.fortuneService = sfs;	
	}
	@Override
	public String getDailyWorkout() {
		// TODO Auto-generated method stub
		return "Swim backwards 10KM";
	}

	@Override
	public String getDailyFortune() {
		// TODO Auto-generated method stub
		return fortuneService.getFortune();
	}

}
