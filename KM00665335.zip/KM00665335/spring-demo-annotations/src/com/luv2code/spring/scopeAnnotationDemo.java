package com.luv2code.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class scopeAnnotationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("AppContext.xml");
		Coach c=context.getBean("tennisCoach",Coach.class);
		Coach c1=context.getBean("tennisCoach",Coach.class);
		boolean result=(c==c1);
		System.out.println(c+"\t"+c1+"\t"+result);
		context.close();
	}

}
