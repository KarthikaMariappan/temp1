package com.luv2code.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class myApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("AppContext.xml");
		
		Coach c=context.getBean("tennisCoach",Coach.class);
		
		System.out.println(c.getDailyWorkout()+"\n"+c.getDailyFortune());
		
		context.close();
	}

}
