package com.luv2code.spring;

import java.util.Random;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class FileFortuneService implements FortuneService {

	
	@Value("${fortunes}")
	private String fortunes;
	String[] fortuneArray;
	@PostConstruct
	void post() {
	fortuneArray=fortunes.split(",");
	}
	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		int random= new Random().nextInt(fortuneArray.length);
		return fortuneArray[random];
	}

}
