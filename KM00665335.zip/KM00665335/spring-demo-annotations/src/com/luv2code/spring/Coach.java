package com.luv2code.spring;

public interface Coach {
public String getDailyWorkout();
public String getDailyFortune();
}
