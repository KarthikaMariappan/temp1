package com.luv2code.spring;

import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class RandomFortuneService implements FortuneService {

	private String[] fortunes={"Life is like a box of chocolates","You have a great future","Your life is wonderful"};
	int random= new Random().nextInt(fortunes.length);
	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return fortunes[random];
	}

}
