package com.luv2code.spring;

public interface FortuneService {

	public String getFortune();
}
