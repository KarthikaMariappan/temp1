package com.luv2code.spring;

public class SadFortuneService implements FortuneService {

	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return "Hope is the Key";
	}

}
