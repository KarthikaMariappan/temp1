package com.luv2code.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringPureConfigDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context1=new AnnotationConfigApplicationContext(LoggerConfig.class);
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(SportConfig.class);
		
		SwimCoach c=context.getBean("swimCoacher",SwimCoach.class);
		System.out.println(c.getDailyWorkout()+"\n"+c.getDailyFortune()+"\n"+c.getTeam()+"\n"+c.getEmail());
		context.close();
	}

}
